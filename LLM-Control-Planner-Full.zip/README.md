# LLM-Control-Planner-Full

This is the full working demo zip with LLM planner and simulated ESP32.