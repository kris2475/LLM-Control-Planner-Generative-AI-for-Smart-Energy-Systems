
# Simulated ESP32 controller
class ESP32Sim:
    def set_target_temp(self, value):
        print(f"Target temperature set to {value}°C")

    def set_heater_power(self, value):
        print(f"Heater power set to {int(value*100)}%")

    def preheat_floor(self, use_solar=True):
        source = "solar energy" if use_solar else "grid energy"
        print(f"Preheating floor using {source}")

    def log_event(self, message):
        print(f"[LOG]: {message}")
