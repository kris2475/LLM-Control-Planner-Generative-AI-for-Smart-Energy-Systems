
# LLM-based Planner (Free version)
import json

def generate_plan(goal, context):
    # Simulate LLM output as JSON plan
    plan = {
        "actions": [
            {"function": "set_target_temp", "args": {"value": 22}},
            {"function": "set_heater_power", "args": {"value": 0.6}},
            {"function": "preheat_floor", "args": {"use_solar": True}},
            {"function": "log_event", "args": {"message": "Preheating using solar surplus, avoiding overshoot"}}
        ]
    }
    return plan
